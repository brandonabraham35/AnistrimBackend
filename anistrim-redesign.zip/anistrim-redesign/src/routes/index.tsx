import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AniStrim — Stream Anime Online" },
      {
        name: "description",
        content:
          "AniStrim — browse and stream anime online. Trending, popular, latest releases, and your personal watchlist.",
      },
      { property: "og:title", content: "AniStrim — Stream Anime Online" },
      {
        property: "og:description",
        content:
          "Browse and stream anime online. Trending, popular, latest releases, and your personal watchlist.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap",
      },
      { rel: "stylesheet", href: "/css/styles.css" },
    ],
  }),
  component: AniStrimApp,
});

const SCRIPTS = [
  "/js/vendor/hls.min.js",
  "/js/vendor/shared/session.js",
  "/js/config.js",
  "/js/api.js",
  "/js/auth.js",
  "/js/router.js",
  "/js/player.js",
  "/js/ui.js",
  "/js/app.js",
];

function loadScript(src: string) {
  return new Promise<void>((resolve, reject) => {
    if (document.querySelector(`script[data-anistrim="${src}"]`)) return resolve();
    const el = document.createElement("script");
    el.src = src;
    el.async = false;
    el.dataset["anistrim"] = src;
    el.onload = () => resolve();
    el.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.body.appendChild(el);
  });
}

function AniStrimApp() {
  useEffect(() => {
    const w = window as unknown as Record<string, any>;
    // Same-origin API base: /api/* is proxied to the existing AniStrim
    // backend by src/routes/api/$.ts (same contract as the Vercel rewrite).
    if (typeof w["__ANISTRIM_API"] === "undefined") w["__ANISTRIM_API"] = "";
    let cancelled = false;
    (async () => {
      for (const src of SCRIPTS) {
        await loadScript(src);
        if (cancelled) return;
      }
      if (w["AniStrimAuth"]?.restoreSession) w["AniStrimAuth"].restoreSession();
      if (w["AniStrimUI"]?.renderHeader) w["AniStrimUI"].renderHeader();
      if (w["AniStrimRouter"]?.render) w["AniStrimRouter"].render();
    })().catch((err) => console.error(err));
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <>
      <div id="app">
        <header className="site-header" id="site-header" />
        <main className="site-main" id="site-main" />
        <footer className="site-footer" id="site-footer" />
      </div>
      <div id="toast-root" className="toast-root" />
    </>
  );
}
