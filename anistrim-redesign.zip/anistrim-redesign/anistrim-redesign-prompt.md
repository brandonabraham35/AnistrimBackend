# Prompt — Redesign AniStrim to match `design-references/`

Copy everything below the line into your AI agent.

---

## Task

Redesign the **frontend/UI only** of my existing AniStrim web app so every page matches the visual quality, layout, spacing, component style and UX of the files in the project's `design-references/` folder (`index.html`, `browse.html`, `search.html`, `watchlist.html`, `history.html`, `upgrade.html`, `watch.html`).

## Hard rules

1. **`design-references/` is the design source of truth.** Open and read every file in it before writing any code. Extract the real values: colors, fonts, radii, spacing rhythm, shadows, card anatomy, hero/slider composition, sidebar structure.
2. **Do not copy the reference project.** Recreate the *design concepts* inside my existing architecture. No new frameworks, no new build tooling, no importing reference HTML/JS wholesale.
3. **My app is the functional source of truth.** Preserve all existing routing (hash router), authentication, API calls, and page behaviour exactly as-is.
4. **Do not touch the backend.** No new endpoints, controllers, env vars, schema or API-contract changes. Frontend files only.
5. **Preserve DOM/JS contracts.** Every existing `id`, class name, `data-*` attribute, inline `onclick` handler and element that JS queries must keep working. Style existing selectors — do not rename them. If new markup is needed, add it *additively* inside existing containers.
6. **No new dependencies.** Pure CSS (plus Google Fonts via `<link>`) and the JS already in the project.

## Implementation order (follow exactly, verify after each step)

1. **Inspect** — read the reference files and my current `css/styles.css` + `js/ui.js`, and list every component the redesign touches.
2. **Shared design system** — one token layer at the top of the stylesheet: color tokens (deep near-black background, layered surfaces, violet accent with gradient + glow, gold rating accent), display font for headings/buttons/brand and a body font, radius scale, spacing scale, three shadow tiers. Every later rule must consume tokens, never raw hex.
3. **Header** — sticky at `top: 0` with `z-index` above content, translucent glass background using `backdrop-filter: blur(18px) saturate(160%)`, hairline bottom border, soft shadow, pill nav links with an active state, rounded search field, gradient avatar/CTA button. Add an opaque `@supports not (backdrop-filter: blur(8px))` fallback. **Warning:** `overflow-x: hidden` on `html`/`body` silently breaks `position: sticky` — use `overflow-x: clip`.
4. **Homepage** — cinematic full-bleed hero slider (gradient scrim, badge, title, meta row, primary + secondary CTA, dot indicators), section headers with an uppercase "see all" link, poster-card grid (2/2.6 aspect ratio, hover lift + accent border + shadow, type/rating/premium badges), and a right-hand sidebar with a ranked top-10 list and a premium CTA card. The sidebar **starts in normal flow and becomes sticky just below the header on scroll** (`position: sticky; top: calc(var(--nav-height) + 20px)`), and collapses to full width below 1024px.
5. **Browse** — page eyebrow + title + result count, rounded filter/toolbar row, responsive `auto-fill minmax(190px, 1fr)` card grid, styled "Load more". Guard against double-wrapped grids with `.anime-grid > .anime-grid { display: contents }`.
6. **Search** — same grid language, styled empty/loading/no-results states.
7. **Watchlist** and **History** — same card/list language, polished empty states, aligned metadata rows.
8. **Upgrade** — centered hero, two pricing cards with the recommended one highlighted (accent border + glow + "Best Value" ribbon), feature list with icons, savings note, gradient subscribe buttons, and a benefits grid below.
9. **Watch/Player** — dark focused layout, rounded player frame, episode list with clear active/hover states, tidy metadata and player-option controls.
10. **Profile/Auth/Settings** — cards, inputs and toggles restyled with the same tokens.
11. **Testing** — verify at 1440px, 1024px, 768px, 480px and 360px: no horizontal overflow, header stays stuck, homepage sidebar sticks and then stacks, grids never collapse to one column, all buttons/links still work, and every page still loads live data.

## Definition of done

- Every page visually reads as one coherent, modern, cinematic streaming product.
- All colors/fonts/radii/shadows come from the token layer.
- Zero functional regressions: routing, auth, API and every existing handler behave exactly as before.
- Zero backend changes.
