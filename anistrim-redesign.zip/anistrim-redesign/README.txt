AniStrim redesign package
=========================

public/css/styles.css      Full stylesheet (original CSS + the v2 redesign layer appended).
                           Drop-in replacement for your existing css/styles.css.
redesign-layer-only.css    Just the appended redesign layer, if you prefer to append it
                           yourself to the end of your current stylesheet.
public/js/*                App JS, unchanged from your original project (included for reference).
src/routes/index.tsx       Preview shell used to boot the vanilla app (Lovable/TanStack only).
src/routes/api/$.ts        Same-origin /api/* passthrough proxy used in preview
                           (mirrors the Vercel rewrite; not needed in production).

Backend: unchanged. No IDs, classes or JS hooks were renamed.
