// ============================================================
//  routes/streamRoutes.js — Multi-API Stream Routes
//  Mounted at /api/stream
// ============================================================
const express = require('express');
const router = express.Router();
const streamController = require('../controllers/streamController');
const { protect } = require('../middleware/auth');

// ── Public: Auto-fallback best stream ──────────────────────
// GET /api/stream/:animeTitle/:episodeNumber
// Optional query param: preferredProvider=consumet|miruro|...
// Optional auth (if token provided, will unlock premium quality)
router.get('/:animeTitle/:episodeNumber', (req, res, next) => {
  // Optional auth — if token present, attach user for tier enforcement
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    try {
      const jwt = require('jsonwebtoken');
      req.user = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET);
    } catch (_) {}
  }
  next();
}, streamController.getStream);

// ── Public: List all providers for "Switch Server" dropdown ─
// GET /api/stream/providers/:animeTitle/:episodeNumber
router.get('/providers/:animeTitle/:episodeNumber', (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    try {
      const jwt = require('jsonwebtoken');
      req.user = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET);
    } catch (_) {}
  }
  next();
}, streamController.listProviders);

// ── Premium-only: Authorize offline download ───────────────
// POST /api/stream/offline-download
router.post('/offline-download', protect, streamController.authorizeDownload);

module.exports = router;
