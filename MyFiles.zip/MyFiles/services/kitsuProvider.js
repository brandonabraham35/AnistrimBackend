const { request } = require('../utils/providerHttp');
const { PROVIDER_IDS } = require('./providerRegistry');

const BASE_URL = process.env.KITSU_BASE_URL || 'https://kitsu.io/api/edge';

function normalize(record) {
  const attributes = record.attributes || {};
  const titles = attributes.titles || {};
  const startDate = attributes.startDate || null;
  const statusMap = { current: 'airing', finished: 'completed', upcoming: 'upcoming', tba: 'upcoming', unreleased: 'upcoming' };
  // Map Kitsu subtype to media_type: "TV", "movie", "OVA", "special"
  const subtypeMap = {
    TV: 'TV',
    movie: 'MOVIE',
    ova: 'OVA',
    ona: 'OVA',
    special: 'SPECIAL',
    music: 'SPECIAL',
  };
  return {
    kitsu_id: String(record.id),
    title: attributes.canonicalTitle || titles.en || titles.en_jp || Object.values(titles)[0] || 'Untitled Anime',
    title_japanese: titles.ja_jp || titles.ja || null,
    description: attributes.synopsis || attributes.description || null,
    cover_image: attributes.posterImage?.original || attributes.posterImage?.large || null,
    banner_image: attributes.coverImage?.original || attributes.coverImage?.large || null,
    episode_count: attributes.episodeCount || 0,
    rating: Number(attributes.averageRating || 0) / 10 || 0,
    season: attributes.season || null,
    year: startDate ? Number(startDate.slice(0, 4)) : null,
    status: statusMap[attributes.status] || 'upcoming',
    media_type: subtypeMap[attributes.subtype] || 'TV',
    age_rating: attributes.ageRating || null,
    popularity: Number(attributes.popularityRank || 0),
    slug: attributes.slug || null,
    genres: [],
    source: PROVIDER_IDS.KITSU,
  };
}

class KitsuProvider {
  async searchAnime(query, limit = 20) {
    const response = await request({ method: 'GET', url: `${BASE_URL}/anime`, params: { 'filter[text]': query, 'page[limit]': limit } });
    return (response.data?.data || []).map(normalize);
  }

  async getAnimeInfo(kitsuId) {
    const response = await request({ method: 'GET', url: `${BASE_URL}/anime/${encodeURIComponent(kitsuId)}` });
    return normalize(response.data.data);
  }
}

module.exports = { KitsuProvider };
