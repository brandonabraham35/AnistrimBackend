// controllers/paymentController.js
const axios = require('axios');
const db = require('../config/db');
const pesapal = require('../services/pesapalService');
require('dotenv').config();

const BACKEND_URL = process.env.BACKEND_URL || 'https://anistrimbackend.onrender.com';

// ── CORRECTED PLANS (monthly = 15000 per spec) ──────────────
const PLANS = {
  monthly: { amount: 15000, label: 'AniStrim Premium Monthly' },
  yearly: { amount: 180000, label: 'AniStrim Premium Yearly' },
};

// ── Premium duration per plan ────────────────────────────────
const PREMIUM_DURATION_DAYS = {
  monthly: 30,
  yearly: 365,
};

// ──────────────────────────────────────────────────────────────
//  NEW: POST /api/payments/checkout
//  Authenticates with Pesapal, registers IPN, submits order,
//  saves a PENDING subscription record, returns redirect URL.
// ──────────────────────────────────────────────────────────────
exports.initializeCheckout = async (req, res) => {
  const { plan } = req.body;
  const userId = req.user.id;

  console.log(`🛒 Checkout: plan=${plan}, userId=${userId}`);

  // Validate plan
  if (!plan || !PLANS[plan]) {
    return res.status(400).json({
      message: `Invalid plan "${plan}". Must be "monthly" or "yearly".`,
    });
  }

  const { amount, label } = PLANS[plan];

  try {
    // Fetch user details
    const [rows] = await db.query(
      'SELECT id, name, email FROM users WHERE id = ?',
      [userId]
    );
    if (!rows.length) {
      return res.status(404).json({ message: 'User not found.' });
    }
    const user = rows[0];

    // Generate a unique merchant reference
    const reference = `ANISTRIM-${userId}-${Date.now()}`;

    // 1. Get Pesapal OAuth token
    const token = await pesapal.getToken();

    // 2. Register / retrieve IPN ID
    const ipnUrl = `${BACKEND_URL}/api/payments/ipn-listener`;
    const ipnId = await pesapal.registerIPN(token, ipnUrl);

    // 3. Build callback URL (user lands here after payment)
    const callbackUrl = `${BACKEND_URL}/api/payments/callback?tx_ref=${reference}`;

    // 4. Submit order to Pesapal
    const orderResult = await pesapal.submitOrder(token, {
      id: reference,
      currency: 'UGX',
      amount: amount,
      description: label,
      callback_url: callbackUrl,
      notification_id: ipnId,
      email: user.email,
      firstName: user.name.split(' ')[0] || user.name,
      lastName: user.name.split(' ').slice(1).join(' ') || '',
    });

    // 5. Save a PENDING subscription record
    await db.query(
      `INSERT INTO subscriptions
        (user_id, reference, amount, currency, status, plan, order_tracking_id)
       VALUES (?, ?, ?, 'UGX', 'PENDING', ?, ?)`,
      [userId, reference, amount, plan, orderResult.order_tracking_id]
    );

    console.log(
      `✅ Checkout complete: ref=${reference}, trackingId=${orderResult.order_tracking_id}`
    );

    res.status(200).json({
      message: 'Payment link created.',
      payment_link: orderResult.redirect_url,
      tx_ref: reference,
      order_tracking_id: orderResult.order_tracking_id,
    });
  } catch (err) {
    console.error('❌ initializeCheckout error:', err.response?.data || err.message);
    res.status(500).json({
      message: 'Could not initiate payment. Please try again.',
    });
  }
};

// ──────────────────────────────────────────────────────────────
//  NEW: GET /api/payments/ipn-listener
//  Public webhook called by Pesapal servers.
//  Pesapal sends query params: OrderTrackingId, OrderMerchantReference
//  We verify the status and update subscription + user record.
// ──────────────────────────────────────────────────────────────
exports.handlePesapalIPN = async (req, res) => {
  const { OrderTrackingId, OrderMerchantReference } = req.query;

  console.log(
    `🔔 IPN received: trackingId=${OrderTrackingId}, ref=${OrderMerchantReference}`
  );

  if (!OrderTrackingId || !OrderMerchantReference) {
    console.error('❌ IPN missing required params');
    return res.status(200).json({ status: 200 }); // Return 200 to acknowledge
  }

  try {
    // 1. Get Pesapal OAuth token
    const token = await pesapal.getToken();

    // 2. Query transaction status from Pesapal
    const txnStatus = await pesapal.getTransactionStatus(token, OrderTrackingId);

    // 3. Find the pending subscription
    const [subs] = await db.query(
      `SELECT * FROM subscriptions
       WHERE reference = ? AND status = 'PENDING'`,
      [OrderMerchantReference]
    );

    if (!subs.length) {
      console.warn(
        `⚠️ IPN: No pending subscription found for ref=${OrderMerchantReference}`
      );
      return res.status(200).json({ status: 200 });
    }

    const subscription = subs[0];

    // 4. Check if payment is completed
    if (!pesapal.isPaymentCompleted(txnStatus.status)) {
      console.log(
        `❌ IPN: Payment not completed (status: ${txnStatus.status}). Marking as FAILED.`
      );
      await db.query(
        `UPDATE subscriptions
         SET status = 'FAILED', payment_method = ?, order_tracking_id = ?
         WHERE id = ?`,
        [txnStatus.payment_method || null, OrderTrackingId, subscription.id]
      );
      return res.status(200).json({ status: 200 });
    }

    // 5. Payment is COMPLETED — calculate premium expiry
    const days = PREMIUM_DURATION_DAYS[subscription.plan] || 30;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + days);

    console.log(
      `✅ IPN: Payment COMPLETED for user ${subscription.user_id}. Premium until ${expiresAt}`
    );

    // 6. Update subscription record
    await db.query(
      `UPDATE subscriptions
       SET status = 'COMPLETED',
           payment_method = ?,
           order_tracking_id = ?,
           paid_at = NOW(),
           expires_at = ?
       WHERE id = ?`,
      [
        txnStatus.payment_method || null,
        OrderTrackingId,
        expiresAt,
        subscription.id,
      ]
    );

    // 7. Grant premium to user
    await db.query(
      `UPDATE users
       SET is_premium = 1, premium_expires_at = ?
       WHERE id = ?`,
      [expiresAt, subscription.user_id]
    );

    console.log(
      `🎉 Premium granted to user ${subscription.user_id} until ${expiresAt}`
    );

    res.status(200).json({ status: 200 });
  } catch (err) {
    console.error('❌ IPN processing error:', err.message);
    // Always return 200 so Pesapal knows we received it
    res.status(200).json({ status: 200 });
  }
};

// POST /api/payments/initiate
exports.initiatePayment = async (req, res) => {
  const { plan } = req.body;
  const userId = req.user.id;

  console.log(`📦 Payment initiation: plan=${plan}, userId=${userId}`);

  // Validate plan explicitly
  if (!plan || !PLANS[plan]) {
    console.error(`❌ Invalid plan received: "${plan}"`);
    return res.status(400).json({ message: `Invalid plan "${plan}". Must be "monthly" or "yearly".` });
  }

  const { amount, label } = PLANS[plan];
  console.log(`💰 Plan: ${plan}, Amount: ${amount}, Label: ${label}`);

  try {
    const [rows] = await db.query('SELECT id, name, email FROM users WHERE id = ?', [userId]);
    if (!rows.length) return res.status(404).json({ message: 'User not found.' });
    const user = rows[0];

    const txRef = `ANISTRIM-${userId}-${Date.now()}`;

    await db.query(
      `INSERT INTO payments (user_id, flw_tx_ref, amount, currency, status, plan) VALUES (?, ?, ?, 'UGX', 'pending', ?)`,
      [userId, txRef, amount, plan]
    );
    console.log(`✅ Payment record created: txRef=${txRef}`);

    const token = await pesapal.getToken();
    const ipnUrl = `${BACKEND_URL}/api/payments/ipn-listener`;
    const ipnId = await pesapal.registerIPN(token, ipnUrl);
    const callbackUrl = `${BACKEND_URL}/api/payments/callback?tx_ref=${txRef}`;

    console.log(`📤 Submitting to Pesapal: amount=${amount}, plan=${plan}, txRef=${txRef}`);

    const orderResult = await pesapal.submitOrder(token, {
      id: txRef,
      currency: 'UGX',
      amount: amount,
      description: label,
      callback_url: callbackUrl,
      notification_id: ipnId,
      email: user.email,
      firstName: user.name.split(' ')[0] || user.name,
      lastName: user.name.split(' ').slice(1).join(' ') || '',
    });

    if (!orderResult.redirect_url) {
      console.error('❌ Pesapal no redirect_url in response');
      return res.status(502).json({ message: 'Payment provider error. Try again.' });
    }

    console.log(`✅ Pesapal redirect URL obtained for ${plan}`);
    res.json({
      message: 'Payment link created.',
      payment_link: orderResult.redirect_url,
      tx_ref: txRef,
      order_tracking_id: orderResult.order_tracking_id,
    });

  } catch (err) {
    console.error('❌ Payment initiation error:', err.response?.data || err.message);
    res.status(500).json({ message: 'Could not initiate payment. Please try again.' });
  }
};

// GET /api/payments/callback
exports.paymentCallback = async (req, res) => {
  const { tx_ref, OrderTrackingId } = req.query;
  const txRef = tx_ref || req.query.OrderMerchantReference;
  if (!txRef) return res.send(buildBridgePage('error', null, 'Missing transaction reference.'));

  try {
    const [rows] = await db.query(`SELECT p.status, p.plan, p.amount FROM payments WHERE flw_tx_ref = ?`, [txRef]);
    const status = rows[0]?.status || 'pending';
    if (OrderTrackingId && rows.length) {
      await db.query(`UPDATE payments SET flw_tx_id = ? WHERE flw_tx_ref = ?`, [OrderTrackingId, txRef]);
    }
    return res.send(buildBridgePage(status, txRef, null));
  } catch (err) {
    console.error('Payment callback error:', err.message);
    return res.send(buildBridgePage('error', txRef, 'Verification error.'));
  }
};

// POST /api/payments/webhook
exports.webhook = async (req, res) => {
  const { orderTrackingId, orderMerchantReference } = req.body;
  if (!orderTrackingId || !orderMerchantReference) return res.status(400).json({ message: 'Invalid webhook data.' });

  try {
    const token = await pesapal.getToken();
    const txnStatus = await pesapal.getTransactionStatus(token, orderTrackingId);

    const txRef = orderMerchantReference;
    const [payments] = await db.query(`SELECT * FROM payments WHERE flw_tx_ref = ? AND status = 'pending'`, [txRef]);
    if (!payments.length) return res.status(200).json({ received: true });

    const payment = payments[0];

    if (!pesapal.isPaymentCompleted(txnStatus.status)) {
      await db.query(`UPDATE payments SET status = 'failed', flw_tx_id = ? WHERE flw_tx_ref = ?`, [orderTrackingId, txRef]);
      return res.status(200).json({ received: true });
    }

    const expiresAt = new Date();
    payment.plan === 'yearly' ? expiresAt.setFullYear(expiresAt.getFullYear() + 1) : expiresAt.setMonth(expiresAt.getMonth() + 1);

    await db.query(`UPDATE payments SET status = 'successful', flw_tx_id = ?, paid_at = NOW() WHERE flw_tx_ref = ?`, [orderTrackingId, txRef]);
    await db.query(`UPDATE users SET is_premium = 1, premium_expires_at = ? WHERE id = ?`, [expiresAt, payment.user_id]);
    console.log(`✅ Premium granted to user ${payment.user_id} until ${expiresAt}`);
    res.status(200).json({ received: true });
  } catch (err) {
    console.error('Webhook error:', err.message);
    res.status(500).json({ message: 'Webhook processing error.' });
  }
};

// GET /api/payments/verify
exports.verifyPayment = async (req, res) => {
  const { tx_ref } = req.query;
  if (!tx_ref) return res.status(400).json({ message: 'tx_ref required.' });
  try {
    const [rows] = await db.query(
      `SELECT p.status, p.plan, p.amount, u.is_premium, u.name FROM payments p JOIN users u ON p.user_id = u.id WHERE p.flw_tx_ref = ?`,
      [tx_ref]
    );
    if (!rows.length) return res.status(404).json({ message: 'Transaction not found.' });
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ message: 'Verification error.' }); }
};

// ──────────────────────────────────────────────────────────────
//  NEW: GET /api/payments/verify-subscription
//  Public — Used by payment-callback.html to poll subscription
//  status from the `subscriptions` table.
// ──────────────────────────────────────────────────────────────
exports.verifySubscriptionPayment = async (req, res) => {
  const { reference } = req.query;
  if (!reference) {
    return res.status(400).json({ message: 'Transaction reference (reference) is required.' });
  }

  try {
    const [rows] = await db.query(
      `SELECT s.status, s.plan, s.amount, s.currency, s.expires_at, s.paid_at,
              u.is_premium, u.name, u.email
       FROM subscriptions s
       JOIN users u ON s.user_id = u.id
       WHERE s.reference = ?`,
      [reference]
    );

    if (!rows.length) {
      return res.status(404).json({ message: 'Subscription not found.' });
    }

    const sub = rows[0];
    res.json({
      status: sub.status,           // 'PENDING', 'COMPLETED', 'FAILED'
      plan: sub.plan,
      amount: sub.amount,
      currency: sub.currency,
      is_premium: sub.is_premium,
      name: sub.name,
      email: sub.email,
      expires_at: sub.expires_at,
      paid_at: sub.paid_at,
    });
  } catch (err) {
    console.error('❌ verifySubscriptionPayment error:', err.message);
    res.status(500).json({ message: 'Verification error.' });
  }
};

// GET /api/payments/revenue
exports.getRevenueStats = async (req, res) => {
  try {
    const [stats] = await db.query(`
      SELECT COUNT(*) AS total_transactions,
        SUM(CASE WHEN status='successful' THEN amount ELSE 0 END) AS total_revenue,
        SUM(CASE WHEN status='successful' AND plan='monthly' THEN 1 ELSE 0 END) AS monthly_subs,
        SUM(CASE WHEN status='successful' AND plan='yearly'  THEN 1 ELSE 0 END) AS yearly_subs,
        SUM(CASE WHEN status='successful' AND DATE(paid_at)=CURDATE() THEN amount ELSE 0 END) AS revenue_today
      FROM payments`);
    const [recent] = await db.query(`
      SELECT p.id, u.name, u.email, p.amount, p.currency, p.status, p.plan, p.paid_at
      FROM payments p JOIN users u ON p.user_id = u.id ORDER BY p.created_at DESC LIMIT 20`);
    res.json({ stats: stats[0], recent });
  } catch (err) { res.status(500).json({ message: 'Could not fetch revenue stats.' }); }
};

// ──────────────────────────────────────────────────────────────
//  NEW: GET /api/payments/subscription-revenue
//  Admin — Returns revenue stats from the `subscriptions` table
// ──────────────────────────────────────────────────────────────
exports.getSubscriptionRevenueStats = async (req, res) => {
  try {
    const [stats] = await db.query(`
      SELECT
        COUNT(*) AS total_transactions,
        SUM(CASE WHEN status = 'COMPLETED' THEN amount ELSE 0 END) AS total_revenue,
        SUM(CASE WHEN status = 'COMPLETED' AND plan = 'monthly' THEN 1 ELSE 0 END) AS monthly_subs,
        SUM(CASE WHEN status = 'COMPLETED' AND plan = 'yearly' THEN 1 ELSE 0 END) AS yearly_subs,
        SUM(CASE WHEN status = 'COMPLETED' AND DATE(paid_at) = CURDATE() THEN amount ELSE 0 END) AS revenue_today,
        SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) AS pending_count,
        SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) AS failed_count
      FROM subscriptions`);

    const [recent] = await db.query(`
      SELECT s.id, u.name, u.email, s.amount, s.currency, s.status, s.plan, s.paid_at, s.created_at, s.reference
      FROM subscriptions s
      JOIN users u ON s.user_id = u.id
      ORDER BY s.created_at DESC
      LIMIT 20`);

    res.json({ stats: stats[0], recent });
  } catch (err) {
    console.error('❌ getSubscriptionRevenueStats error:', err.message);
    res.status(500).json({ message: 'Could not fetch subscription revenue stats.' });
  }
};

function buildBridgePage(status, txRef, errorMsg) {
  const appLink = `anistrim://payment-result?tx_ref=${txRef || ''}&status=${status}`;
  if (status === 'successful') {
    return `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=${appLink}"><title>Payment Successful</title><style>*{margin:0;padding:0;box-sizing:border-box}body{background:#0a0a0f;color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;font-family:sans-serif}.box{background:#1a1a2e;border:1px solid #22c55e;border-radius:16px;padding:32px 24px;text-align:center;max-width:340px;width:100%}h2{color:#22c55e;margin-bottom:10px}p{color:#aaa;font-size:.85rem;margin-bottom:24px;line-height:1.6}a{display:block;background:#6c2bd9;color:#fff;padding:14px;border-radius:10px;text-decoration:none;font-weight:600}</style></head><body><div class="box"><div style="font-size:3rem;margin-bottom:16px">🎉</div><h2>Payment Successful!</h2><p>Welcome to AniStrim Premium! Tap below to start watching.</p><a href="${appLink}" id="btn">🎬 Open AniStrim</a></div><script>setTimeout(function(){document.getElementById('btn').click()},150);</script></body></html>`;
  }
  if (status === 'pending') {
    return `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=${appLink}"><title>Payment Pending</title><style>*{margin:0;padding:0;box-sizing:border-box}body{background:#0a0a0f;color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;font-family:sans-serif}.box{background:#1a1a2e;border:1px solid #f97316;border-radius:16px;padding:32px 24px;text-align:center;max-width:340px;width:100%}h2{color:#f97316;margin-bottom:10px}p{color:#aaa;font-size:.85rem;margin-bottom:24px;line-height:1.6}a{display:block;background:#6c2bd9;color:#fff;padding:14px;border-radius:10px;text-decoration:none;font-weight:600}</style></head><body><div class="box"><div style="font-size:3rem;margin-bottom:16px">⏳</div><h2>Payment Processing</h2><p>Your payment is being confirmed.</p><a href="${appLink}" id="btn">← Back to AniStrim</a></div><script>setTimeout(function(){document.getElementById('btn').click()},150);</script></body></html>`;
  }
  const upgradeLink = 'anistrim://upgrade';
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Payment Failed</title><style>*{margin:0;padding:0;box-sizing:border-box}body{background:#0a0a0f;color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;font-family:sans-serif}.box{background:#1a1a2e;border:1px solid #ef4444;border-radius:16px;padding:32px 24px;text-align:center;max-width:340px;width:100%}h2{color:#ef4444;margin-bottom:10px}p{color:#aaa;font-size:.85rem;margin-bottom:24px;line-height:1.6}a{display:block;background:#6c2bd9;color:#fff;padding:14px;border-radius:10px;text-decoration:none;font-weight:600;margin-bottom:8px}</style></head><body><div class="box"><div style="font-size:3rem;margin-bottom:16px">❌</div><h2>Payment Failed</h2><p>${errorMsg || 'Your payment was not completed. You have not been charged.'}</p><a href="${upgradeLink}" id="btn">Try Again</a></div><script>setTimeout(function(){document.getElementById('btn').click()},150);</script></body></html>`;
}
